# Local native-free bigint compatibility prototype

Private, locally authored package; not an upstream patched release. Four public conversion functions preserve ordinary unsigned values for observed Solana layouts of8,16,24and32bytes. Node>=20, CommonJS and ESM named exports. There are no dependencies or lifecycle scripts and no native addon path.

Encode accepts a primitive bigint and an integer width1..32; negative and overflowing values throw before allocation. Decode accepts Buffer or Uint8Array of0..32bytes, respects view offsets and returns0n for empty input. Inputs are not mutated. SharedArrayBuffer-backed inputs are rejected. Output is a fresh Buffer.

The32byte ceiling is deliberate and specific to observed callers, not whole-library equivalence: custom exported parent bigInt(length) above32 is unsupported. Strings, numbers, arrays, DataView, coercible objects, fractional/zero/negative/infinite widths, signed and out-of-range values are not silently coerced/truncated. Uint8Array BE behavior is intentionally normalized rather than reproducing upstream fallback's Buffer-only assumption. Browser bundling, arbitrary proxies/subclasses, concurrency, native implementation parity and unobserved consumers are not claimed safe.

Preserve LICENSE, NOTICE, local identity and all provenance on distribution. Do not relabel this as an upstream fix, publish it, or infer that name-based audit disappearance proves remediation. Production and all five security/compliance gates remain separate.
