'use strict';
// Local Aegis replacement, 2026-09-05. Not upstream bigint-buffer code or release.
// Observed four-function API compatibility; intentionally stricter invalid inputs.
// No native addon, dynamic loader, dependencies, or implicit coercion.
const {Buffer}=require('node:buffer');
const {isUint8Array,isSharedArrayBuffer}=require('node:util').types;
const MAX_BYTES=32;
const typedArrayPrototype=Object.getPrototypeOf(Uint8Array.prototype);
const lengthOf=Object.getOwnPropertyDescriptor(typedArrayPrototype,'length').get;
const bufferOf=Object.getOwnPropertyDescriptor(typedArrayPrototype,'buffer').get;
function bytes(value){
  if(!isUint8Array(value))throw new TypeError('Expected Buffer or Uint8Array');
  if(isSharedArrayBuffer(bufferOf.call(value)))throw new TypeError('Shared buffers are unsupported');
  const length=lengthOf.call(value);
  if(length>MAX_BYTES)throw new RangeError('Input exceeds 32-byte local contract');
  return {input:value,length};
}
function width(value){
  if(typeof value!=='number'||!Number.isInteger(value)||value<1||value>MAX_BYTES)throw new RangeError('Width must be an integer from 1 to 32');
  return value;
}
function decode(input,little){
  const {input:b,length}=bytes(input);let value=0n;
  for(let i=0;i<length;i++)value=(value<<8n)|BigInt(b[little?length-1-i:i]);
  return value;
}
function encode(value,size,little){
  size=width(size);
  if(typeof value!=='bigint')throw new TypeError('Expected bigint');
  if(value<0n||value>>BigInt(size*8)!==0n)throw new RangeError('Value is outside unsigned width');
  const out=Buffer.alloc(size);
  for(let i=0;i<size;i++){out[little?i:size-1-i]=Number(value&255n);value>>=8n;}
  return out;
}
exports.toBigIntLE=input=>decode(input,true);
exports.toBigIntBE=input=>decode(input,false);
exports.toBufferLE=(value,size)=>encode(value,size,true);
exports.toBufferBE=(value,size)=>encode(value,size,false);
