// Local Aegis bounded replacement, 2026-09-05; not upstream declarations.
/// <reference types="node" />
export declare function toBigIntLE(input: Uint8Array): bigint;
export declare function toBigIntBE(input: Uint8Array): bigint;
export declare function toBufferLE(value: bigint, width: number): Buffer;
export declare function toBufferBE(value: bigint, width: number): Buffer;
