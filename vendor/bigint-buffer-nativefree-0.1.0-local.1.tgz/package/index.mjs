// Local Aegis replacement, 2026-09-05; see NOTICE and README.
import api from './index.cjs';
export const {toBigIntLE,toBigIntBE,toBufferLE,toBufferBE}=api;
